# Online-Bakery-Shop

Flat and responsive one page template, designed and coded by Farah Aamir.

Coded in clean HTML5, CSS3, and Bootstrap.

Demo: https://farah2911.github.io/Online-Bakery-Shop/
