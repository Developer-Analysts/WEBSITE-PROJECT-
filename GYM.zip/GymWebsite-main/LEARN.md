# Gym Fitness Website

Fitness website to be linked with a fitness app. Started as a school project.

## Technologies Used:

* HTML5
* CSS3
* JavaScript

## `Silent Features`:

* Responsive Design.
* Portfolio Template.
* Unique and Dynamic Design.
* Contains HOME, ABOUT, SERVICES, CLASSES, SCHEDULE ,PRICE and many other sections.


[`Click the Demo Button  and View Live Project`](https://mian-ali.github.io/GymWebsite/)


## `Project Live Url`:

(https://mian-ali.github.io/GymWebsite/)
