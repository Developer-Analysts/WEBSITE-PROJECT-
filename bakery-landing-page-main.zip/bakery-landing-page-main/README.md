# bakery-landing-page

    Make Responsive Website Using HTML SCSS & JavaScript

# Video tutorial

    https://youtu.be/Oq19HVbblDc

# Resource

    Google font: https://fonts.google.com/

    Boxicons: https://boxicons.com/

    Images: https://unsplash.com/

    SwiperJS: https://swiperjs.com/

# Preview

!["Responsive Website Using HTML SCSS & JavaScript"](https://user-images.githubusercontent.com/67447840/137575094-d97968a4-8ddb-457a-b027-8f4e4c442b08.png "Responsive Website Using HTML SCSS & JavaScript")